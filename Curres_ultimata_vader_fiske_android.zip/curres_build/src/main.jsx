import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Activity, AlertTriangle, ArrowDown, ArrowUp, BrainCircuit, CalendarDays,
  Cloud, CloudDrizzle, CloudFog, CloudLightning, CloudRain, CloudSnow, CloudSun,
  Droplets, Gauge, MapPin, Navigation, RefreshCw, Search, Sun, Sunrise, Sunset,
  Thermometer, Umbrella, Wind, Fish, Waves, Moon, CalendarCheck, ChevronLeft, ChevronRight
} from "lucide-react";
import "./styles.css";

const API = "https://api.open-meteo.com/v1/forecast";
const GEO = "https://geocoding-api.open-meteo.com/v1/search";
const DEFAULT_PLACE = { name: "Kristianstad", admin1: "Skåne län", country: "Sverige", latitude: 56.0294, longitude: 14.1567, timezone: "Europe/Stockholm" };
const FISHING_PLACES = {
  Karlskrona: { name: "Karlskrona", latitude: 56.1612, longitude: 15.5869 },
  Ronneby: { name: "Ronneby", latitude: 56.2076, longitude: 15.2760 },
  Karlshamn: { name: "Karlshamn", latitude: 56.1706, longitude: 14.8619 },
  Sölvesborg: { name: "Sölvesborg", latitude: 56.0521, longitude: 14.5753 },
  "Hällevik": { name: "Hällevik", latitude: 56.0153, longitude: 14.7001 },
};
function moonPhase(dateString) {
  const d = new Date(`${dateString}T12:00:00Z`);
  const knownNewMoon = Date.UTC(2000, 0, 6, 18, 14);
  const synodic = 29.530588853;
  const age = (((d.getTime() - knownNewMoon) / 86400000) % synodic + synodic) % synodic;
  const fraction = age / synodic;
  const illum = Math.round((1 - Math.cos(2 * Math.PI * fraction)) * 50);
  let phase = fraction < .04 || fraction > .96 ? "Nymåne" : fraction < .23 ? "Tilltagande måne" : fraction < .27 ? "Första kvarteret" : fraction < .48 ? "Tilltagande måne" : fraction < .52 ? "Fullmåne" : fraction < .73 ? "Avtagande måne" : fraction < .77 ? "Sista kvarteret" : "Avtagande måne";
  const emoji = fraction < .04 || fraction > .96 ? "🌑" : fraction < .23 ? "🌒" : fraction < .27 ? "🌓" : fraction < .48 ? "🌔" : fraction < .52 ? "🌕" : fraction < .73 ? "🌖" : fraction < .77 ? "🌗" : "🌘";
  return { phase, illum, emoji };
}
function fishingScore(day, index) {
  // Transparent heuristic, not a guarantee of fish activity.
  let score = 72;
  const wind = Number(day.wind_speed_10m_max || 0);
  const rain = Number(day.precipitation_sum || 0);
  const pressure = Number(day.pressure_msl_mean || 1013);
  if (wind <= 15) score += 12; else if (wind <= 25) score += 5; else if (wind > 35) score -= 28; else if (wind > 28) score -= 15;
  if (rain <= 1) score += 5; else if (rain > 8) score -= 10;
  if (pressure >= 1005 && pressure <= 1025) score += 5; else if (pressure < 990 || pressure > 1035) score -= 8;
  const moon = moonPhase(day.time);
  if (moon.phase === "Nymåne" || moon.phase === "Fullmåne") score += 4;
  return Math.max(20, Math.min(98, Math.round(score)));
}

function weatherInfo(code) {
  if (code === 0) return { label: "Klart", icon: Sun };
  if ([1, 2].includes(code)) return { label: code === 1 ? "Mestadels klart" : "Växlande molnighet", icon: CloudSun };
  if (code === 3) return { label: "Mulet", icon: Cloud };
  if ([45, 48].includes(code)) return { label: "Dimma", icon: CloudFog };
  if ([51, 53, 55, 56, 57].includes(code)) return { label: "Duggregn", icon: CloudDrizzle };
  if ([61, 63, 65, 66, 67, 80, 81, 82].includes(code)) return { label: "Regn", icon: CloudRain };
  if ([71, 73, 75, 77, 85, 86].includes(code)) return { label: "Snö", icon: CloudSnow };
  if ([95, 96, 99].includes(code)) return { label: "Åska", icon: CloudLightning };
  return { label: "Blandat väder", icon: CloudSun };
}
const weekday = (date, options = { weekday: "short" }) => new Intl.DateTimeFormat("sv-SE", options).format(new Date(`${date}T12:00:00`));
const fmtTime = (date) => date ? date.slice(11, 16) : "—";
const round = (n) => Math.round(Number(n));
const safe = (n, suffix = "") => Number.isFinite(Number(n)) ? `${round(n)}${suffix}` : "—";

function makeInsight(current, daily, hourly) {
  const today = daily?.time?.[0];
  const max = daily?.temperature_2m_max?.[0];
  const min = daily?.temperature_2m_min?.[0];
  const rainChance = Math.max(...(hourly?.precipitation_probability || []).slice(0, 12).map(Number).filter(Number.isFinite), 0);
  const rainHours = (hourly?.precipitation_probability || []).slice(0, 12).filter(v => Number(v) >= 50).length;
  const wind = Number(current?.wind_speed_10m || 0);
  const code = Number(current?.weather_code ?? 3);
  const parts = [];
  if (rainChance >= 60) parts.push(`Regnrisken är förhöjd, med upp till ${rainChance}% nederbördssannolikhet under de kommande timmarna. Ta gärna med paraply.`);
  else if (rainChance >= 35) parts.push(`Det finns viss risk för regn (upp till ${rainChance}% under de närmaste timmarna). En lätt regnjacka kan vara bra.`);
  else parts.push("Det ser relativt torrt ut de närmaste timmarna utifrån nederbördsprognosen.");
  if (wind >= 35) parts.push("Det blåser en hel del, så tänk på vinden om du ska cykla eller vistas ute.");
  else if (wind >= 20) parts.push("Det kan kännas blåsigt, särskilt i öppna områden.");
  if (code === 0 || code === 1) parts.push("Passa gärna på att få lite dagsljus medan det är klart.");
  if (Number.isFinite(Number(max)) && Number.isFinite(Number(min))) parts.push(`Dagens temperatur väntas ligga mellan ${round(min)}° och ${round(max)}°C.`);
  if (rainHours > 0) parts.push(`Prognosen visar ${rainHours} timme/timmar med minst 50% regnrisk under den närmaste 12-timmarsperioden.`);
  return parts.join(" ");
}

function App() {
  const [place, setPlace] = useState(DEFAULT_PLACE);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [weather, setWeather] = useState(null);
  const [busy, setBusy] = useState(false);
  const [searching, setSearching] = useState(false);
  const [error, setError] = useState("");
  const [lastUpdated, setLastUpdated] = useState(null);
  const [useLocation, setUseLocation] = useState(false);
  const [activeTab, setActiveTab] = useState("weather");
  const [fishingPlace, setFishingPlace] = useState("Karlskrona");
  const [fishType, setFishType] = useState("Abborre");
  const [fishingData, setFishingData] = useState(null);
  const [fishingBusy, setFishingBusy] = useState(false);
  const [fishingError, setFishingError] = useState("");
  const [calendarMonth, setCalendarMonth] = useState(new Date().getMonth());

  async function loadWeather(target = place) {
    setBusy(true); setError("");
    try {
      const params = new URLSearchParams({
        latitude: target.latitude, longitude: target.longitude,
        current: "temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m,wind_direction_10m",
        hourly: "temperature_2m,precipitation_probability,precipitation,weather_code,wind_speed_10m",
        daily: "weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,precipitation_probability_max,precipitation_sum,wind_speed_10m_max",
        timezone: target.timezone || "auto", forecast_days: "7"
      });
      const response = await fetch(`${API}?${params}`);
      if (!response.ok) throw new Error("Väderleverantören svarade inte som väntat.");
      const data = await response.json();
      setWeather(data); setLastUpdated(new Date());
    } catch (e) {
      setError("Kunde inte hämta väderdata. Kontrollera internetanslutningen och försök igen.");
    } finally { setBusy(false); }
  }

  useEffect(() => { loadWeather(DEFAULT_PLACE); }, []);

  async function loadFishing(targetName = fishingPlace) {
    const target = FISHING_PLACES[targetName] || FISHING_PLACES.Karlskrona;
    setFishingBusy(true); setFishingError("");
    try {
      const params = new URLSearchParams({
        latitude: target.latitude, longitude: target.longitude,
        daily: "weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,precipitation_sum,precipitation_probability_max,wind_speed_10m_max,wind_direction_10m_dominant",
        hourly: "pressure_msl,wind_speed_10m,precipitation_probability",
        forecast_days: "16", timezone: "Europe/Stockholm"
      });
      const response = await fetch(`${API}?${params}`);
      if (!response.ok) throw new Error("Väderdata kunde inte hämtas.");
      const data = await response.json();
      // Add daily mean pressure using the 24 hourly observations for each day.
      data.daily.pressure_msl_mean = data.daily.time.map((date) => {
        const values = data.hourly.time.map((t, i) => t.startsWith(date) ? Number(data.hourly.pressure_msl[i]) : null).filter(v => v !== null && Number.isFinite(v));
        return values.length ? values.reduce((a,b) => a+b,0)/values.length : 1013;
      });
      setFishingData(data);
    } catch (e) { setFishingError("Fiskekalendern kunde inte hämta väderdata. Kontrollera internetanslutningen."); }
    finally { setFishingBusy(false); }
  }
  useEffect(() => { if (activeTab === "fishing" && !fishingData && !fishingBusy) loadFishing(); }, [activeTab]);

  async function searchPlaces(e) {
    e?.preventDefault();
    const term = query.trim();
    if (!term) return;
    setSearching(true); setError(""); setResults([]);
    try {
      const response = await fetch(`${GEO}?name=${encodeURIComponent(term)}&count=6&language=sv&format=json`);
      if (!response.ok) throw new Error();
      const data = await response.json();
      setResults(data.results || []);
      if (!data.results?.length) setError("Hittade ingen plats. Prova en annan stavning.");
    } catch { setError("Kunde inte söka efter plats just nu."); }
    finally { setSearching(false); }
  }

  function choosePlace(p) {
    const next = { ...p, name: p.name, admin1: p.admin1 || "", country: p.country || "", timezone: p.timezone || "auto" };
    setPlace(next); setQuery(""); setResults([]); loadWeather(next);
  }

  function locateMe() {
    if (!navigator.geolocation) { setError("Din webbläsare stöder inte platsdelning."); return; }
    setUseLocation(true); setError("");
    navigator.geolocation.getCurrentPosition(async pos => {
      const next = { name: "Min plats", admin1: "GPS-position", country: "", latitude: pos.coords.latitude, longitude: pos.coords.longitude, timezone: "auto" };
      setPlace(next); setUseLocation(false); loadWeather(next);
    }, () => { setError("Platsåtkomst nekades eller kunde inte hämtas. Sök efter en ort i stället."); setUseLocation(false); }, { enableHighAccuracy: false, timeout: 10000 });
  }

  const current = weather?.current;
  const daily = weather?.daily;
  const hourly = weather?.hourly;
  const currentInfo = weatherInfo(current?.weather_code);
  const CurrentIcon = currentInfo.icon;
  const insight = useMemo(() => current && daily && hourly ? makeInsight(current, daily, hourly) : "", [current, daily, hourly]);
  const rainAlert = useMemo(() => {
    if (!hourly) return null;
    const now = current?.time || "";
    const idx = Math.max(0, hourly.time.findIndex(t => t >= now));
    const slice = hourly.precipitation_probability.slice(idx, idx + 12);
    const max = Math.max(0, ...slice.map(Number).filter(Number.isFinite));
    const at = slice.findIndex(v => Number(v) === max);
    if (max < 40) return { level: "low", title: "Ingen tydlig regnvarning", body: "Regnrisken är låg de närmaste timmarna enligt prognosen.", max };
    return { level: max >= 70 ? "high" : "medium", title: max >= 70 ? "Hög risk för regn" : "Möjligt regn på väg", body: `Högsta beräknade regnrisk är ${max}%${at >= 0 ? ` omkring kl. ${fmtTime(hourly.time[idx + at])}` : ""}.`, max };
  }, [hourly, current]);

  const nowIndex = hourly && current ? Math.max(0, hourly.time.findIndex(t => t >= current.time)) : 0;
  const nextHours = hourly ? Array.from({ length: 8 }, (_, i) => nowIndex + i).filter(i => i < hourly.time.length) : [];

  return (
    <div className="app-shell">
      <div className="ambient ambient-one" /><div className="ambient ambient-two" />
      <header className="topbar">
        <a className="brand" href="#" aria-label="Curres ultimata väder och fiske startsida">
          <span className="brand-mark"><CloudSun size={23} /></span>
          <span className="brand-name">Curres ultimata väder &amp; fiske<small>SMART WEATHER · FISHING SYSTEM</small></span>
        </a>
        <div className="top-actions">
          <span className="live-pill"><span /> LIVE DATA</span>
          <button className="icon-btn" onClick={() => loadWeather()} disabled={busy} aria-label="Uppdatera väder"><RefreshCw size={17} className={busy ? "spin" : ""}/></button>
        </div>
      </header>

      <main>
        <section className="welcome-row">
          <div><p className="eyebrow">DIN PERSONLIGA VÄDER- OCH FISKEASSISTENT</p><h1>Väder &amp; fiske, <span>fast smartare.</span></h1><p className="subhead">Prognoser i realtid och fiskedagar planerade för Blekinges kust.</p></div>
          <div className="data-status"><span className="status-dot" /> OPEN-METEO <span className="status-sep">/</span> LIVE</div>
        </section>

        <nav className="app-tabs" aria-label="Appavdelningar">
          <button className={activeTab === "weather" ? "active" : ""} onClick={() => setActiveTab("weather")}><CloudSun size={17}/> Väder</button>
          <button className={activeTab === "fishing" ? "active" : ""} onClick={() => { setActiveTab("fishing"); if (!fishingData && !fishingBusy) loadFishing(); }}><Fish size={17}/> Fiskekalender Blekinge</button>
        </nav>
        {activeTab === "weather" && <>
        <section className="search-wrap">
          <form className="searchbar" onSubmit={searchPlaces}>
            <Search size={19} />
            <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Sök stad eller ort..." aria-label="Sök stad eller ort" />
            <button type="button" className="gps-button" onClick={locateMe} disabled={useLocation}><Navigation size={15}/><span>{useLocation ? "Hämtar..." : "Min plats"}</span></button>
            <button type="submit" className="search-submit" disabled={searching}>{searching ? "Söker..." : "Sök"}</button>
          </form>
          {results.length > 0 && <div className="search-results">{results.map((r, i) => <button key={`${r.latitude}-${r.longitude}-${i}`} onClick={() => choosePlace(r)}><MapPin size={16}/><span><b>{r.name}</b><small>{[r.admin1, r.country].filter(Boolean).join(", ")}</small></span><span className="result-arrow">↗</span></button>)}</div>}
          {error && <div className="error-message"><AlertTriangle size={16}/>{error}</div>}
        </section>

        {!weather && busy ? <div className="loading-card"><div className="loader"/><p>Hämtar aktuell väderdata…</p></div> : current && <>
          <section className="hero-grid">
            <article className="current-card glass">
              <div className="card-topline"><span className="tag"><MapPin size={13}/>{place.name}</span><span className="muted">{place.admin1}{place.admin1 && place.country ? ", " : ""}{place.country}</span></div>
              <div className="current-main">
                <div className="temperature-block"><div className="temperature">{safe(current.temperature_2m)}<span>°</span></div><div className="feels-like">Känns som {safe(current.apparent_temperature, "°C")}</div></div>
                <div className="weather-illustration"><div className="orb-glow"/><CurrentIcon size={92} strokeWidth={1.2}/></div>
              </div>
              <h2>{currentInfo.label}</h2>
              <p className="current-description">{weekday(current.time.slice(0,10), {weekday:"long", day:"numeric", month:"long"})} <span>·</span> Just nu</p>
              <div className="current-stats">
                <div><span className="stat-icon"><Wind size={17}/></span><span className="stat-label">Vind</span><b>{safe(current.wind_speed_10m, " km/h")}</b></div>
                <div><span className="stat-icon"><Droplets size={17}/></span><span className="stat-label">Luftfuktighet</span><b>{safe(current.relative_humidity_2m, "%")}</b></div>
                <div><span className="stat-icon"><Umbrella size={17}/></span><span className="stat-label">Nederbörd</span><b>{safe(current.precipitation, " mm")}</b></div>
              </div>
            </article>
            <article className="insight-card glass">
              <div className="section-heading"><div className="heading-icon ai-icon"><BrainCircuit size={19}/></div><div><p className="eyebrow">AI INSIGHT</p><h2>Dagens väderanalys</h2></div><span className="sparkle">✦</span></div>
              <p className="insight-text">{insight || "Analyserar dagens väder..."}</p>
              <div className={`rain-alert ${rainAlert?.level || "low"}`}>
                <div className="alert-icon">{rainAlert?.level === "high" ? <CloudRain size={20}/> : <Umbrella size={20}/>}</div>
                <div><b>{rainAlert?.title || "Kontrollerar regnrisken"}</b><p>{rainAlert?.body || "Hämtar nederbördsprognos."}</p></div>
              </div>
              <div className="insight-footer"><span><Activity size={14}/> Baserat på prognosdata</span><span className="confidence">DYNAMISK ANALYS</span></div>
            </article>
          </section>

          <section className="panel glass hourly-panel">
            <div className="section-heading"><div className="heading-icon"><Activity size={18}/></div><div><p className="eyebrow">NÄRMSTA TIMMARNA</p><h2>Timprognos</h2></div><span className="section-note">Lokal tid</span></div>
            <div className="hourly-scroll">{nextHours.map(i => { const inf = weatherInfo(hourly.weather_code[i]); const Icon = inf.icon; return <div className={`hour-item ${i === nowIndex ? "hour-now" : ""}`} key={hourly.time[i]}><span className="hour-time">{i === nowIndex ? "Nu" : fmtTime(hourly.time[i])}</span><Icon size={24} strokeWidth={1.5}/><b>{safe(hourly.temperature_2m[i], "°")}</b><span className="hour-rain"><Droplets size={12}/>{safe(hourly.precipitation_probability[i], "%")}</span></div>; })}</div>
          </section>

          <section className="panel glass forecast-panel">
            <div className="section-heading"><div className="heading-icon"><CalendarDays size={18}/></div><div><p className="eyebrow">PLANERA FRAMÅT</p><h2>7-dagarsprognos</h2></div><span className="section-note">Nästa 7 dagar</span></div>
            <div className="forecast-list">{daily.time.map((date, i) => { const inf = weatherInfo(daily.weather_code[i]); const Icon = inf.icon; const max = Number(daily.temperature_2m_max[i]); const min = Number(daily.temperature_2m_min[i]); const low = Math.min(...daily.temperature_2m_min.map(Number)); const high = Math.max(...daily.temperature_2m_max.map(Number)); const left = ((min - low) / Math.max(1, high - low)) * 100; const width = Math.max(8, ((max - min) / Math.max(1, high - low)) * 100); return <div className="forecast-row" key={date}><span className="forecast-day">{i === 0 ? "Idag" : weekday(date)}</span><span className="forecast-condition"><Icon size={21} strokeWidth={1.5}/><span>{inf.label}</span></span><span className="forecast-rain"><Droplets size={13}/>{safe(daily.precipitation_probability_max[i], "%")}</span><b className="temp-low">{safe(min)}°</b><div className="temp-track"><span style={{ left: `${left}%`, width: `${width}%` }}/></div><b className="temp-high">{safe(max)}°</b></div>; })}</div>
          </section>

          <section className="bottom-grid">
            <article className="mini-card glass"><div className="mini-title"><Sunrise size={18}/><span>Soluppgång</span></div><b>{daily?.sunrise?.[0]?.slice(11,16) || "—"}</b><small>Idag</small></article>
            <article className="mini-card glass"><div className="mini-title"><Sunset size={18}/><span>Solnedgång</span></div><b>{daily?.sunset?.[0]?.slice(11,16) || "—"}</b><small>Idag</small></article>
            <article className="mini-card glass"><div className="mini-title"><Wind size={18}/><span>Max vind</span></div><b>{safe(daily?.wind_speed_10m_max?.[0], " km/h")}</b><small>Förväntad idag</small></article>
            <article className="mini-card glass"><div className="mini-title"><Gauge size={18}/><span>Regn totalt</span></div><b>{safe(daily?.precipitation_sum?.[0], " mm")}</b><small>Förväntat idag</small></article>
          </section>
        </>}
        </>}
        {activeTab === "fishing" && <section className="fishing-area">
          <div className="fishing-intro glass">
            <div className="section-heading"><div className="heading-icon fish-icon"><Fish size={20}/></div><div><p className="eyebrow">BLEKINGE · ÖSTERSJÖN</p><h2>Fiskekalender</h2></div><span className="section-note">16-dagars väderunderlag</span></div>
            <p className="fishing-copy">Jämför dagar med hjälp av vind, nederbörd, lufttryck, månfas och dagsljus. Poängen är en vägledande väderbaserad uppskattning – inte en garanti för napp.</p>
            <div className="fishing-controls">
              <label>Fiskeplats<select value={fishingPlace} onChange={e => { setFishingPlace(e.target.value); setFishingData(null); loadFishing(e.target.value); }}>
                {Object.keys(FISHING_PLACES).map(name => <option key={name} value={name}>{name}</option>)}
              </select></label>
              <label>Fiskart<select value={fishType} onChange={e => setFishType(e.target.value)}><option>Abborre</option><option>Gädda</option><option>Gös</option><option>Havsöring</option><option>Torsk</option><option>Allmänt kustfiske</option></select></label>
              <button className="search-submit refresh-fishing" onClick={() => loadFishing()} disabled={fishingBusy}><RefreshCw size={15} className={fishingBusy ? "spin" : ""}/> Uppdatera</button>
            </div>
          </div>
          {fishingError && <div className="error-message"><AlertTriangle size={16}/>{fishingError}</div>}
          {fishingBusy && !fishingData && <div className="loading-card glass"><div className="loader"/><p>Beräknar fiskedagar för {fishingPlace}…</p></div>}
          {fishingData && <>
            <div className="fishing-summary-grid">
              {fishingData.daily.time.slice(0,3).map((date,i) => { const score=fishingScore({ ...Object.fromEntries(Object.entries(fishingData.daily).map(([k,v])=>[k,Array.isArray(v)?v[i]:v])), time:date },i); return <article className="fish-day-highlight glass" key={date}><div className="fish-day-top"><span>{i===0?"Idag":weekday(date,{weekday:"long"})}</span><span className={`score-badge ${score>=80?"good":score>=65?"fair":"low"}`}>{score}/100</span></div><h3>{score>=80?"Lovande fiskedag":score>=65?"Möjlig fiskedag":"Mer osäkra förhållanden"}</h3><div className="fish-mini-stats"><span><Wind size={14}/>{safe(fishingData.daily.wind_speed_10m_max[i]," km/h")}</span><span><CloudRain size={14}/>{safe(fishingData.daily.precipitation_probability_max[i],"%")}</span><span><Sunrise size={14}/>{fishingData.daily.sunrise[i]?.slice(11,16)||"—"}</span></div></article>; })}
            </div>
            <div className="panel glass fishing-calendar-panel">
              <div className="calendar-header"><div className="section-heading"><div className="heading-icon"><CalendarCheck size={18}/></div><div><p className="eyebrow">PLANERA DITT NÄSTA PASS</p><h2>Kommande fiskedagar</h2></div></div><span className="calendar-month">{fishingPlace} · {fishType}</span></div>
              <div className="fishing-list">{fishingData.daily.time.map((date,i) => { const day = Object.fromEntries(Object.entries(fishingData.daily).map(([k,v])=>[k,Array.isArray(v)?v[i]:v])); day.time=date; const score=fishingScore(day,i); const moon=moonPhase(date); const inf=weatherInfo(day.weather_code); const Icon=inf.icon; return <article className="fishing-row" key={date}><div className="fishing-date"><b>{weekday(date,{day:"numeric"})}</b><span>{weekday(date,{month:"short",weekday:"short"})}</span></div><div className="fishing-weather"><Icon size={22}/><span>{inf.label}<small>{safe(day.temperature_2m_min)}° till {safe(day.temperature_2m_max)}°C</small></span></div><div className="fishing-wind"><Wind size={15}/><span>{safe(day.wind_speed_10m_max)} km/h<small>vind</small></span></div><div className="fishing-moon"><span>{moon.emoji}</span><small>{moon.phase}<br/>{moon.illum}% ljus</small></div><div className="fishing-sun"><span><Sunrise size={14}/>{day.sunrise?.slice(11,16)||"—"}</span><span><Sunset size={14}/>{day.sunset?.slice(11,16)||"—"}</span></div><div className="fishing-score"><b className={score>=80?"score-good":score>=65?"score-fair":"score-low"}>{score}</b><span>fiskepoäng</span><div className="score-track"><i style={{width:`${score}%`}}/></div></div></article>; })}</div>
              <p className="fishing-disclaimer">Fiskepoängen väger samman väderförhållanden och månfas med enkla tumregler. Den är inte en vetenskapligt validerad fångstprognos. Kontrollera alltid lokala fiskeregler, fredningstider och eventuella varningar innan du fiskar.</p>
            </div>
          </>}
        </section>}
      </main>
      <footer><div className="footer-brand"><span className="brand-mark small"><CloudSun size={16}/></span><b>Curres ultimata väder &amp; fiske</b></div><span>Väderdata från Open-Meteo · Ingen API-nyckel krävs</span><span>{lastUpdated ? `Uppdaterad ${lastUpdated.toLocaleTimeString("sv-SE", {hour:"2-digit", minute:"2-digit"})}` : "Ansluter…"}</span></footer>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
