# Curres ultimata väder & fiske

Svensk väderapp med Open-Meteo-data och fiskekalender för Blekinge.

## Funktioner
- Aktuellt väder, timprognos och 7-dagarsprognos.
- Ortsökning och GPS-position.
- Regelbaserad väderanalys och regnrisk.
- Fiskekalender för Karlskrona, Ronneby, Karlshamn, Sölvesborg och Hällevik.
- Väderbaserad fiskepoäng, månfas och solupp-/nedgång för upp till 16 dagar.
- Androidprojekt som kan byggas till APK via GitHub Actions.

## Kör webbversionen lokalt
Kräver Node.js 20 eller senare.

```bash
npm install
npm run dev
```

## Skapa Android-APK
1. Skapa ett nytt repository på GitHub och ladda upp innehållet i den här mappen.
2. Öppna fliken **Actions** i GitHub och kör arbetsflödet **Build Android APK** (Run workflow). Det startar även automatiskt vid push till `main` eller `master`.
3. När jobbet är klart, öppna körningen och hämta artefakten `curres-ultimata-vader-fiske-apk`.
4. Packa upp artefakten och installera `app-debug.apk` på din Android. Om Android frågar, tillåt installation från den app du använder för att öppna filen.

Detta paket innehåller källkod och automatisk APK-byggning; själva APK-filen måste skapas av GitHub Actions. APK:n är en debug-byggnad, inte en Play Store-release.

## Fiskepoäng
Poängen är en enkel, transparent heuristik baserad på vind, nederbörd, lufttryck och månfas. Den är vägledande, inte vetenskapligt validerad och garanterar inte fångst. Kontrollera lokala regler, fredningstider och säkerhetsvarningar.

## Datakälla
Väderdata från [Open-Meteo](https://open-meteo.com/). Gratis API utan nyckel för icke-kommersiell användning; följ deras licens- och attribueringsvillkor.
